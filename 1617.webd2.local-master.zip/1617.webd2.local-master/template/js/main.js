;(function() {
  alert('Welcome to the GDM Web Template developed by drdynscript!');
})();